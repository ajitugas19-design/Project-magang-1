<?php
// Login.php — redirect ke index.php (entry point utama)
require_once "config.php";

if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: Router.php?page=dashboard");
} else {
    header("Location: index.php");
}
exit;
?>
