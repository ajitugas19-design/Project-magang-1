<?php
// ============================================================
// CONFIG.PHP — Sesuaikan kredensial database sebelum di-hosting
// ============================================================
// Untuk hosting (cPanel / shared hosting), ubah nilai di bawah:
//   DB_HOST : biasanya "localhost"
//   DB_USER : username database dari cPanel
//   DB_PASS : password database dari cPanel
//   DB_NAME : nama database yang sudah dibuat di cPanel
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // ganti dengan user database hosting Anda
define('DB_PASS', '');           // ganti dengan password database hosting Anda
define('DB_NAME', 'km1');        // ganti dengan nama database hosting Anda

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$koneksi = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

mysqli_set_charset($koneksi, 'utf8mb4');
?>
