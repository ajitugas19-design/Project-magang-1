<?php
require_once "config.php";

// Jika sudah login, langsung ke dashboard
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: Router.php?page=dashboard");
    exit;
}

$error = "";

if (isset($_POST['login'])) {
    $nama  = $_POST['nama'] ?? '';
    $sandi = $_POST['sandi'] ?? '';

    $stmt = mysqli_prepare($koneksi, "SELECT * FROM pengguna WHERE nama = ? AND sandi = ?");
    mysqli_stmt_bind_param($stmt, "ss", $nama, $sandi);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        $_SESSION['login'] = true;
        $_SESSION['nama']  = $data['nama'];
        header("Location: Router.php?page=dashboard");
        exit;
    } else {
        $error = "Username / Password salah!";
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Sistem KM</title>
<style>
body {
    margin: 0; height: 100vh; display: flex; justify-content: center; align-items: center;
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #3b5f6f, #4fa3b1);
}
.login-box {
    background: #fff; padding: 45px 60px; width: 500px; border-radius: 9px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2); text-align: center;
}
.form-group { text-align: left; margin-bottom: 14px; }
label { font-size: 16px; font-weight: bold; display: block; margin-bottom: 4px; }
input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 15px; }
.error { color: red; font-size: 14px; margin-bottom: 10px; }
button {
    width: 100%; padding: 12px; border: none; background: #2fa4b9; color: white;
    border-radius: 5px; cursor: pointer; font-size: 16px; font-weight: bold; margin-top: 8px;
}
button:hover { background: #248fa0; }
h1 { color: #3b5f6f; }
</style>
</head>
<body>

<div class="login-box">
    <h1>Login</h1>

    <form method="post">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="nama" required autocomplete="username">
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="sandi" required autocomplete="current-password">
        </div>

        <?php if (!empty($error)): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <button type="submit" name="login">Masuk</button>
    </form>
</div>

</body>
</html>
