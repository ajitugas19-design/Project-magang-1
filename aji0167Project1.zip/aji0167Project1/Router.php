<?php
require_once "config.php";

$page = $_GET['page'] ?? 'login';

// Jika sudah login dan akses halaman login, arahkan ke dashboard
if (isset($_SESSION['login']) && $_SESSION['login'] === true && $page === 'login') {
    $page = 'dashboard';
}

// Halaman yang butuh login
$protected = ['dashboard', 'cekdata'];

if (in_array($page, $protected) && (!isset($_SESSION['login']) || $_SESSION['login'] !== true)) {
    header("Location: Router.php?page=login");
    exit;
}

switch ($page) {

    case 'dashboard':
        require 'Dashbord.php';
        break;

    case 'cekdata':
        require 'Cekdata.php';
        break;

    case 'login':
        require 'index.php';
        break;

    case 'logout':
        session_unset();
        session_destroy();
        header("Location: Router.php?page=login");
        exit;

    default:
        http_response_code(404);
        echo "<h2>Halaman tidak ditemukan</h2><a href='Router.php?page=login'>Kembali</a>";
}
?>
