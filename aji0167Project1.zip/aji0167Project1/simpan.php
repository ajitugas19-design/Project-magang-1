<?php
require_once 'config.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: Router.php?page=login");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: Router.php?page=dashboard");
    exit;
}

// Ambil data form
$kode      = trim($_POST['kode'] ?? '');
$nopol     = trim($_POST['nopol'] ?? '');
$kendaraan = trim($_POST['kendaraan'] ?? '');
$sopir     = trim($_POST['sopir'] ?? '');
$status    = trim($_POST['status'] ?? '');
$tgl_out   = $_POST['tgl_out'] ?: null;
$tgl_in    = $_POST['tgl_in'] ?: null;
$jam_out   = $_POST['jam_out'] ?: null;
$jam_in    = $_POST['jam_in'] ?: null;
$bu        = trim($_POST['bu'] ?? '');
$bu2       = trim($_POST['bu2'] ?? '');
$material  = trim($_POST['material'] ?? '');
$material2 = trim($_POST['material2'] ?? '');
$ket       = trim($_POST['ket'] ?? '');
$ket2      = trim($_POST['ket2'] ?? '');
$km_datang = $_POST['km_datang'] !== '' ? (int)$_POST['km_datang'] : null;
$km_keluar = $_POST['km_keluar'] !== '' ? (int)$_POST['km_keluar'] : null;
$km_total  = $_POST['km_total'] !== '' ? (int)$_POST['km_total'] : null;

$edit_id      = $_POST['edit_id'] ?? '';
$search_nopol = $_POST['search_nopol'] ?? '';
$search_date  = $_POST['search_date'] ?? '';

if (!empty($edit_id)) {
    // UPDATE
    $stmt = mysqli_prepare($koneksi,
        "UPDATE data_km SET
            kode=?, nopol=?, kendaraan=?, sopir=?, status=?,
            tgl_out=?, tgl_in=?, jam_out=?, jam_in=?,
            bu=?, bu2=?, material=?, material2=?, ket=?, ket2=?,
            km_datang=?, km_keluar=?, km_total=?
        WHERE id=?"
    );
    mysqli_stmt_bind_param($stmt, "sssssssssssssssiiis",
        $kode, $nopol, $kendaraan, $sopir, $status,
        $tgl_out, $tgl_in, $jam_out, $jam_in,
        $bu, $bu2, $material, $material2, $ket, $ket2,
        $km_datang, $km_keluar, $km_total,
        $edit_id
    );

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Data berhasil diupdate!";
    } else {
        $_SESSION['error'] = "Gagal mengupdate data: " . mysqli_stmt_error($stmt);
    }
    mysqli_stmt_close($stmt);

    header("Location: Cekdata.php?search_nopol=" . urlencode($search_nopol) . "&search_date=" . urlencode($search_date));
    exit;

} else {
    // INSERT
    $stmt = mysqli_prepare($koneksi,
        "INSERT INTO data_km
            (kode, nopol, kendaraan, sopir, status,
             tgl_out, tgl_in, jam_out, jam_in,
             bu, bu2, material, material2, ket, ket2,
             km_datang, km_keluar, km_total)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    );
    mysqli_stmt_bind_param($stmt, "ssssssssssssssssii",
        $kode, $nopol, $kendaraan, $sopir, $status,
        $tgl_out, $tgl_in, $jam_out, $jam_in,
        $bu, $bu2, $material, $material2, $ket, $ket2,
        $km_datang, $km_keluar, $km_total
    );

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Data berhasil disimpan!";
    } else {
        $_SESSION['error'] = "Gagal menyimpan data: " . mysqli_stmt_error($stmt);
    }
    mysqli_stmt_close($stmt);

    header("Location: Router.php?page=dashboard");
    exit;
}
?>
