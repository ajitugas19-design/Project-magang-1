<?php
require_once 'config.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: Router.php?page=login");
    exit;
}

$edit_id      = (int)($_GET['id'] ?? 0);
$search_nopol = $_GET['search_nopol'] ?? '';
$search_date  = $_GET['search_date']  ?? '';

if (!$edit_id) {
    header("Location: Cekdata.php");
    exit;
}

$stmt = mysqli_prepare($koneksi, "SELECT * FROM data_km WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $edit_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data   = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$data) {
    header("Location: Cekdata.php");
    exit;
}

// BU datalist
$query_bu = mysqli_query($koneksi, "SELECT bu FROM bu ORDER BY bu ASC");
$bu_list  = "";
while ($row = mysqli_fetch_assoc($query_bu)) {
    $bu_list .= "<option value='" . htmlspecialchars($row['bu']) . "'>";
}

// Material datalist
$query_material = mysqli_query($koneksi, "SELECT material FROM material ORDER BY material ASC");
$material_list  = "";
while ($row = mysqli_fetch_assoc($query_material)) {
    $material_list .= "<option value='" . htmlspecialchars($row['material']) . "'>";
}

// Kendaraan autocomplete
$query_kendaraan = mysqli_query($koneksi, "SELECT nopol, sopir, kendaraan FROM kendaraan ORDER BY nopol ASC");
$kendaraan_list  = "";
$kendaraan_data  = [];
while ($row = mysqli_fetch_assoc($query_kendaraan)) {
    $kendaraan_list .= "<option value='" . htmlspecialchars($row['nopol']) . "'>";
    $kendaraan_data[] = ['nopol' => $row['nopol'], 'sopir' => $row['sopir'], 'kendaraan' => $row['kendaraan']];
}
$kendaraan_json = json_encode($kendaraan_data);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data KM</title>
    <style>
        body { font-family:Arial,sans-serif; background:#f2f2f2; margin:0; }
        .container { width:900px; max-width:98%; margin:30px auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 4px 8px rgba(0,0,0,0.1); }
        h2 { text-align:center; margin:0; }
        .form-row { display:flex; gap:20px; margin-bottom:10px; }
        .form-group { flex:1; display:flex; align-items:center; padding:5px; border-radius:4px; }
        label { width:150px; font-weight:bold; flex-shrink:0; }
        input, select { flex:1; padding:8px; border-radius:4px; border:1px solid #ccc; }
        input[readonly] { background:#e9ecef; }
        .navbar { display:flex; justify-content:space-between; align-items:center; padding:15px 30px; margin-bottom:25px; background:#f8f9fa; border-bottom:1px solid #ddd; }
        .navbar a { display:inline-block; padding:8px 18px; background:#007bff; color:white; text-decoration:none; border-radius:4px; font-weight:500; }
        .group-out { background:#e8f5e9; }
        .group-in  { background:#fce4e4; }
        .group-neutral { background:#f0f0f0; }
        .flash-success { background:#d4edda; color:#155724; padding:12px 20px; border:1px solid #c3e6cb; border-radius:4px; margin-bottom:12px; }
        .flash-error   { background:#f8d7da; color:#721c24; padding:12px 20px; border:1px solid #f5c6cb; border-radius:4px; margin-bottom:12px; }
    </style>
</head>
<body>

<?php if (isset($_SESSION['success'])): ?>
    <div class="flash-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div class="flash-error"><?= htmlspecialchars($_SESSION['error']) ?></div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<div class="container">
    <div class="navbar">
        <div>Login sebagai: <b><?= htmlspecialchars($_SESSION['nama'] ?? '') ?></b></div>
        <h2>FORM EDIT KM</h2>
        <a href="Cekdata.php?search_nopol=<?= urlencode($search_nopol) ?>&search_date=<?= urlencode($search_date) ?>">&#8592; KEMBALI</a>
    </div>

    <form method="POST" action="simpan.php">
        <input type="hidden" name="edit_id" value="<?= $edit_id ?>">
        <input type="hidden" name="search_nopol" value="<?= htmlspecialchars($search_nopol) ?>">
        <input type="hidden" name="search_date" value="<?= htmlspecialchars($search_date) ?>">

        <div class="form-row">
            <div class="form-group group-neutral">
                <label>Kode</label>
                <input type="text" name="kode" value="<?= htmlspecialchars($data['kode']) ?>" readonly>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group group-out">
                <label>Nopol</label>
                <input type="text" name="nopol" list="data_kendaraan" id="nopol_input" value="<?= htmlspecialchars($data['nopol']) ?>" placeholder="Ketik nopol...">
                <datalist id="data_kendaraan"><?= $kendaraan_list ?></datalist>
            </div>
            <div class="form-group group-in">
                <label>Kendaraan</label>
                <input type="text" name="kendaraan" value="<?= htmlspecialchars($data['kendaraan']) ?>">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group group-out">
                <label>Nama Sopir</label>
                <input type="text" name="sopir" value="<?= htmlspecialchars($data['sopir']) ?>">
            </div>
            <div class="form-group group-in">
                <label>Status</label>
                <select name="status">
                    <option value="CLOSE" <?= $data['status'] === 'CLOSE' ? 'selected' : '' ?>>CLOSE</option>
                    <option value="OPEN"  <?= $data['status'] === 'OPEN'  ? 'selected' : '' ?>>OPEN</option>
                </select>
            </div>
        </div>

        <hr>

        <div class="form-row">
            <div class="form-group group-out">
                <label>Tanggal Keluar</label>
                <input type="date" name="tgl_out" value="<?= htmlspecialchars($data['tgl_out']) ?>">
            </div>
            <div class="form-group group-in">
                <label>Tanggal Masuk</label>
                <input type="date" name="tgl_in" value="<?= htmlspecialchars($data['tgl_in']) ?>">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group group-out">
                <label>Jam Keluar</label>
                <input type="time" name="jam_out" value="<?= htmlspecialchars($data['jam_out']) ?>">
            </div>
            <div class="form-group group-in">
                <label>Jam Masuk</label>
                <input type="time" name="jam_in" value="<?= htmlspecialchars($data['jam_in']) ?>">
            </div>
        </div>

        <hr>

        <div class="form-row">
            <div class="form-group group-out">
                <label>BU 1</label>
                <input type="text" name="bu" list="data_bu" value="<?= htmlspecialchars($data['bu']) ?>">
                <datalist id="data_bu"><?= $bu_list ?></datalist>
            </div>
            <div class="form-group group-in">
                <label>BU 2</label>
                <input type="text" name="bu2" list="data_bu" value="<?= htmlspecialchars($data['bu2']) ?>">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group group-out">
                <label>Material 1</label>
                <input type="text" name="material" list="data_material" value="<?= htmlspecialchars($data['material']) ?>">
                <datalist id="data_material"><?= $material_list ?></datalist>
            </div>
            <div class="form-group group-in">
                <label>Material 2</label>
                <input type="text" name="material2" list="data_material" value="<?= htmlspecialchars($data['material2']) ?>">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group group-out">
                <label>Keterangan 1</label>
                <input type="text" name="ket" value="<?= htmlspecialchars($data['ket']) ?>">
            </div>
            <div class="form-group group-in">
                <label>Keterangan 2</label>
                <input type="text" name="ket2" value="<?= htmlspecialchars($data['ket2']) ?>">
            </div>
        </div>

        <hr>

        <div class="form-row">
            <div class="form-group group-out">
                <label>KM Keluar</label>
                <input type="number" name="km_keluar" id="km_keluar" value="<?= htmlspecialchars($data['km_keluar']) ?>">
            </div>
            <div class="form-group group-in">
                <label>KM Masuk</label>
                <input type="number" name="km_datang" id="km_datang" value="<?= htmlspecialchars($data['km_datang']) ?>">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group group-neutral">
                <label>KM Total</label>
                <input type="number" name="km_total" id="km_total" value="<?= htmlspecialchars($data['km_total']) ?>" readonly style="font-weight:bold;color:blue;">
            </div>
        </div>

        <br>
        <div style="text-align:right;">
            <button type="submit" style="background:green;color:white;padding:10px 25px;border:none;border-radius:5px;cursor:pointer;font-weight:bold;">
                Update Data
            </button>
        </div>
    </form>
</div>

<script>
const datang = document.getElementById("km_datang");
const keluar = document.getElementById("km_keluar");
const total  = document.getElementById("km_total");

function hitungKM() {
    const d = parseInt(datang.value) || 0;
    const k = parseInt(keluar.value) || 0;
    total.value = Math.max(0, d - k);
}
datang.addEventListener("input", hitungKM);
keluar.addEventListener("input", hitungKM);

// Kendaraan autocomplete
const kendaraanData = <?= $kendaraan_json ?>;
const nopolInput    = document.getElementById('nopol_input');
const sopirInput    = document.querySelector('input[name="sopir"]');
const kendaraanInput= document.querySelector('input[name="kendaraan"]');

nopolInput.addEventListener('input', function () {
    const nopol = this.value.toUpperCase().trim();
    const match = kendaraanData.find(item =>
        item.nopol.toUpperCase() === nopol ||
        item.nopol.toUpperCase().startsWith(nopol)
    );
    if (match) {
        sopirInput.value    = match.sopir;
        kendaraanInput.value= match.kendaraan;
        this.style.backgroundColor = '#d4edda';
    } else {
        this.style.backgroundColor = '';
    }
});

// Enter key navigasi
document.querySelectorAll('input, select').forEach(function (field, index, fields) {
    field.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (fields[index + 1]) fields[index + 1].focus();
        }
    });
});
</script>
</body>
</html>
