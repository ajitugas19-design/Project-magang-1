<?php
require_once 'config.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: Router.php?page=login");
    exit;
}

$search_nopol = $_GET['search_nopol'] ?? '';
$search_date  = $_GET['search_date']  ?? '';

$sql = "SELECT dk.*, k.sopir AS sopir_master, k.kendaraan AS kendaraan_master
        FROM data_km dk
        LEFT JOIN kendaraan k ON dk.nopol = k.nopol
        WHERE 1=1";

$params = [];
$types  = '';

if (!empty($search_nopol)) {
    $sql .= " AND dk.nopol LIKE ?";
    $params[] = '%' . $search_nopol . '%';
    $types   .= 's';
}
if (!empty($search_date)) {
    $sql .= " AND (dk.tgl_out = ? OR dk.tgl_in = ?)";
    $params[] = $search_date;
    $params[] = $search_date;
    $types   .= 'ss';
}

$sql .= " ORDER BY dk.created_at DESC";

$stmt = mysqli_prepare($koneksi, $sql);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Data KM</title>
<style>
*{ box-sizing:border-box; }
body { font-family:Segoe UI,Arial,sans-serif; background:#eef2f5; padding:15px; margin:0; }
.container { max-width:100%; margin:0 auto; background:white; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,.1); overflow:hidden; }
.header { display:flex; justify-content:space-between; align-items:center; padding:15px 20px; border-bottom:1px solid #27c8f0; background:white; }
.header h2{ margin:0; }
.search-section { padding:15px 20px; background:#f9f9f9; border-bottom:1px solid #ddd; }
.form-group { display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; }
.input-box { flex:1; min-width:200px; }
.input-box label { font-size:12px; font-weight:bold; display:block; margin-bottom:4px; }
.input-box input { width:100%; padding:8px; border:1px solid #ccc; border-radius:4px; }
.btn { padding:9px 16px; border:none; border-radius:4px; font-weight:bold; cursor:pointer; text-decoration:none; display:inline-block; }
.btn-gray { background:#6c757d; color:white; }
.btn-blue { background:#007bff; color:white; }
.btn-green { background:#28a745; color:white; }
.table-container { overflow-x:auto; }
table { width:100%; border-collapse:collapse; table-layout:fixed; }
th,td { border:1px solid #ddd; padding:6px 4px; font-size:12px; white-space:normal; word-wrap:break-word; overflow-wrap:break-word; }
th { background:#f1f1f1; text-align:center; }
tbody tr:hover { background:#e3f2fd; }
td:last-child { font-weight:bold; color:#007bff; }
.footer-bar { padding:10px 20px; display:flex; justify-content:space-between; align-items:center; }
.footer-note { font-size:11px; color:#888; }
@media(max-width:600px){ .form-group{ flex-direction:column; } }
</style>
</head>
<body>

<?php if (isset($_SESSION['success'])): ?>
    <div style="background:#d4edda;color:#155724;padding:12px 20px;border:1px solid #c3e6cb;">
        <?= htmlspecialchars($_SESSION['success']) ?>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div style="background:#f8d7da;color:#721c24;padding:12px 20px;border:1px solid #f5c6cb;">
        <?= htmlspecialchars($_SESSION['error']) ?>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<div class="container">
    <div class="header">
        <h2>DAFTAR DATA KM</h2>
        <a href="Router.php?page=dashboard" class="btn btn-blue">&larr; KEMBALI</a>
    </div>

    <div class="search-section">
        <form method="GET" action="Cekdata.php">
            <div class="form-group">
                <div class="input-box">
                    <label>TANGGAL</label>
                    <input type="date" name="search_date" value="<?= htmlspecialchars($search_date) ?>">
                </div>
                <div class="input-box">
                    <label>NOPOL</label>
                    <input type="text" name="search_nopol" value="<?= htmlspecialchars($search_nopol) ?>">
                </div>
                <button type="submit" class="btn btn-blue">CARI</button>
                <a href="Cekdata.php" class="btn btn-gray">RESET</a>
            </div>
        </form>
    </div>

    <div class="table-container">
        <table>
            <thead>
            <tr>
                <th style="width:60px">KODE</th>
                <th style="width:90px">NOPOL</th>
                <th style="width:120px">SOPIR</th>
                <th style="width:130px">KENDARAAN</th>
                <th style="width:70px">STATUS</th>
                <th style="width:90px">TGL OUT</th>
                <th style="width:70px">JAM OUT</th>
                <th style="width:60px">BU 1</th>
                <th style="width:110px">MAT. 1</th>
                <th style="width:80px">KET 1</th>
                <th style="width:90px">TGL IN</th>
                <th style="width:70px">JAM IN</th>
                <th style="width:60px">BU 2</th>
                <th style="width:110px">MAT. 2</th>
                <th style="width:80px">KET 2</th>
                <th style="width:80px">KM OUT</th>
                <th style="width:80px">KM IN</th>
                <th style="width:90px">TOTAL</th>
                <th style="width:100px">AKSI</th>
            </tr>
            </thead>
            <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr ondblclick="window.location='edit.php?id=<?= (int)$row['id'] ?>&search_nopol=<?= urlencode($search_nopol) ?>&search_date=<?= urlencode($search_date) ?>'">
                    <td><?= htmlspecialchars($row['kode']) ?></td>
                    <td><?= htmlspecialchars($row['nopol']) ?></td>
                    <td><?= htmlspecialchars($row['sopir']) ?></td>
                    <td><?= htmlspecialchars($row['kendaraan']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td><?= htmlspecialchars($row['tgl_out']) ?></td>
                    <td><?= htmlspecialchars($row['jam_out']) ?></td>
                    <td><?= htmlspecialchars($row['bu']) ?></td>
                    <td><?= htmlspecialchars($row['material']) ?></td>
                    <td><?= htmlspecialchars($row['ket']) ?></td>
                    <td><?= htmlspecialchars($row['tgl_in']) ?></td>
                    <td><?= htmlspecialchars($row['jam_in']) ?></td>
                    <td><?= htmlspecialchars($row['bu2']) ?></td>
                    <td><?= htmlspecialchars($row['material2']) ?></td>
                    <td><?= htmlspecialchars($row['ket2']) ?></td>
                    <td><?= htmlspecialchars($row['km_keluar']) ?></td>
                    <td><?= htmlspecialchars($row['km_datang']) ?></td>
                    <td style="font-weight:bold"><?= htmlspecialchars($row['km_total']) ?></td>
                    <td>
                        <form method="post" action="hapus.php" style="display:inline" onsubmit="return confirm('Hapus data <?= htmlspecialchars($row['kode']) ?>?')">
                            <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                            <input type="hidden" name="search_nopol" value="<?= htmlspecialchars($search_nopol) ?>">
                            <input type="hidden" name="search_date" value="<?= htmlspecialchars($search_date) ?>">
                            <button type="submit" style="background:#dc3545;color:white;padding:5px 10px;font-size:12px;border:none;border-radius:3px;cursor:pointer">HAPUS</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="19" style="text-align:center;color:#888;padding:20px;">Data tidak ditemukan</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="footer-bar">
        <span class="footer-note">Double-click baris untuk mengedit data</span>
        <a href="export_xls.php?search_date=<?= urlencode($search_date) ?>&search_nopol=<?= urlencode($search_nopol) ?>" class="btn btn-green">&#8595; EXPORT XLS</a>
    </div>
</div>

</body>
</html>
