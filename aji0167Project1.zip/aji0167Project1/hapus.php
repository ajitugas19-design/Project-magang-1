<?php
require_once 'config.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: Router.php?page=login");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $stmt = mysqli_prepare($koneksi, "DELETE FROM data_km WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Data berhasil dihapus!";
    } else {
        $_SESSION['error'] = "Error hapus: " . mysqli_stmt_error($stmt);
    }
    mysqli_stmt_close($stmt);
}

$search_nopol = $_POST['search_nopol'] ?? $_GET['search_nopol'] ?? '';
$search_date  = $_POST['search_date']  ?? $_GET['search_date']  ?? '';

header("Location: Cekdata.php?search_nopol=" . urlencode($search_nopol) . "&search_date=" . urlencode($search_date));
exit;
?>
